<?= $q['infoFrm'] ?>
<?= $q['frmPing'] ?>
<div class="ui message" id="pingResponse">

</div>
<?php if (isset($ajax)) { ?>
    <?= $script_foot ?>
<?php } ?>