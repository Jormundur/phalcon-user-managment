<div class="page-header">
<?= $q['servhost'] ?><div style="margin-left: 80%"><?= $q['btn'] ?></div>
</div>
<?= $q['serveurs'] ?>
