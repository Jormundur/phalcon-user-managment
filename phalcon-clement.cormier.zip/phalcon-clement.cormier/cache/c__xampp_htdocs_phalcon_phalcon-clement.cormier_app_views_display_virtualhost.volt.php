<?= $q['servhost'] ?><?= $q['btn'] ?><?= $q['btn2'] ?>
<?= $q['virtualhost'] ?>
<?= $q['de1-4'] ?>
<?= $q['lv1-2'] ?>