<div class="page-header">
    <h1>Virtualhosts</h1>
</div>
<p>Page de test temporaire</p>
<h3>Déjà implémenté, ou pour exemple</h3>
<?= $q['btApache'] ?> <?= $q['btNginx'] ?> <?= $q['btStypes'] ?> <?= $q['btAdmin'] ?> <?= $q['btEx'] ?>
<div id="file"></div>
<h3>A implémenter</h3>
<?= $q['grid'] ?>
<?php if (($ajax)) { ?>
<?= $script_foot ?>
<?php } ?>
