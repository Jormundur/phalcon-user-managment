Le module framework-web a �t� tr�s int�ressant. Bien que difficile au d�but,
la seconde partie de ce module (apr�s User-managment), m'a beaucoup plus attir�.
On a vraiment pu voir la puissance et l'utilit� des frameworks et autres outils.
Je ne pensais pas ma�triser des outils comme semantic et bootstrap et je sais que cela sera toujours utile.

Concernant Github, j'ai r�alis� au moins 1 commit par s�ance plus du travail chez moi � finir des applications
et � me pr�parer au cours � venir.
